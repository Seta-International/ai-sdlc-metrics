// Planner module — shared data
const PLANNER_DATA = {
  PLAN: {
    id: 'pl-q1-launch',
    name: 'Q1 Launch · Web Planner',
    members: 12,
  },

  LABELS: [
    { slot: 1, name: 'backend', color: '#7170ff' },
    { slot: 2, name: 'ui', color: '#06b6d4' },
    { slot: 3, name: 'blocker', color: '#ef4444' },
    { slot: 4, name: 'research', color: '#f59e0b' },
    { slot: 5, name: 'copy', color: '#10b981' },
    { slot: 6, name: 'perf', color: '#ec4899' },
  ],

  MEMBERS: [
    { id: 'u1', name: 'Ana Silva', initials: 'AS', color: '#7170ff' },
    { id: 'u2', name: 'Mei Chen', initials: 'MC', color: '#06b6d4' },
    { id: 'u3', name: 'Diego R.', initials: 'DR', color: '#10b981' },
    { id: 'u4', name: 'Priya P.', initials: 'PP', color: '#f59e0b' },
    { id: 'u5', name: 'Omar H.', initials: 'OH', color: '#ef4444' },
    { id: 'u6', name: 'Kai T.', initials: 'KT', color: '#ec4899' },
    { id: 'u7', name: 'Nora B.', initials: 'NB', color: '#8b5cf6' },
  ],

  BUCKETS: [
    {
      id: 'b-backlog', name: 'Backlog', count: 9,
      tasks: [
        { id: 't1', title: 'Decide on grouping rules for custom views', priority: 3, progress: 0, due: null, labels: [1, 4], assignees: ['u1'], comments: 3, attach: 0, checklist: [0, 0] },
        { id: 't2', title: 'Spec: evidence upload from mobile', priority: 3, progress: 0, due: '2026-05-02', labels: [4], assignees: ['u2', 'u3'], comments: 1, attach: 2, checklist: [0, 0] },
        { id: 't3', title: 'Decide telemetry retention window', priority: 1, progress: 0, due: null, labels: [], assignees: [], comments: 0, attach: 0, checklist: [0, 0] },
        { id: 't4', title: 'Carry-over policy for My Day', priority: 3, progress: 0, due: '2026-05-10', labels: [4, 5], assignees: ['u4'], comments: 2, attach: 0, checklist: [0, 0] },
      ],
    },
    {
      id: 'b-todo', name: 'To do', count: 7,
      tasks: [
        { id: 't5', title: 'Column reorder via drag handle — polish drop indicator', priority: 5, progress: 0, due: '2026-04-24', labels: [2], assignees: ['u2'], comments: 4, attach: 1, checklist: [2, 5], cover: true },
        { id: 't6', title: 'Replace skeleton loaders on task detail panel', priority: 3, progress: 0, due: '2026-04-28', labels: [2], assignees: ['u5'], comments: 0, attach: 0, checklist: [0, 0] },
        { id: 't7', title: 'Due-date badge: today / overdue / this week states', priority: 3, progress: 0, due: '2026-04-23', labels: [2, 5], assignees: ['u2', 'u6'], comments: 6, attach: 0, checklist: [3, 3] },
        { id: 't8', title: 'Ship label editor — 12 slot ceiling', priority: 9, progress: 0, due: '2026-04-22', labels: [1, 2, 3], assignees: ['u1', 'u2', 'u3'], comments: 8, attach: 3, checklist: [1, 4] },
      ],
    },
    {
      id: 'b-inprogress', name: 'In progress', count: 6,
      tasks: [
        { id: 't9', title: 'Board virtualization for 400+ card columns', priority: 5, progress: 50, due: '2026-04-25', labels: [6, 1], assignees: ['u3', 'u7'], comments: 12, attach: 0, checklist: [4, 8] },
        { id: 't10', title: 'Charts: weekly trend panel with drill-through', priority: 5, progress: 50, due: '2026-04-29', labels: [2, 4], assignees: ['u6'], comments: 3, attach: 1, checklist: [2, 3] },
        { id: 't11', title: 'Quick-add task: inline label + assignee chips', priority: 3, progress: 50, due: null, labels: [2], assignees: ['u4', 'u5'], comments: 1, attach: 0, checklist: [0, 0] },
      ],
    },
    {
      id: 'b-review', name: 'In review', count: 4,
      tasks: [
        { id: 't12', title: 'Conflict-resolver modal — "keep mine / keep theirs"', priority: 3, progress: 50, due: '2026-04-23', labels: [1, 2], assignees: ['u1', 'u3'], comments: 5, attach: 0, checklist: [3, 3] },
        { id: 't13', title: 'Rewrite: Plans list empty state copy', priority: 1, progress: 50, due: null, labels: [5], assignees: ['u6'], comments: 2, attach: 0, checklist: [0, 0] },
      ],
    },
    {
      id: 'b-done', name: 'Done', count: 11,
      tasks: [
        { id: 't14', title: 'Grid view: saved column widths per-user', priority: 3, progress: 100, due: '2026-04-18', labels: [2], assignees: ['u2'], comments: 1, attach: 0, checklist: [2, 2] },
        { id: 't15', title: 'Evidence attachment: PDF + image preview', priority: 3, progress: 100, due: '2026-04-15', labels: [1], assignees: ['u3', 'u1'], comments: 4, attach: 2, checklist: [3, 3] },
        { id: 't16', title: 'View-state sync with URL query params', priority: 5, progress: 100, due: '2026-04-12', labels: [1, 2], assignees: ['u7'], comments: 2, attach: 0, checklist: [0, 0] },
      ],
    },
  ],

  MY_DAY: [
    { title: 'Ship label editor — 12 slot ceiling', plan: 'Q1 Launch', priority: 9, due: 'today', progress: 50, labels: [1, 2], assignees: ['u1', 'u2'] },
    { title: 'Review: conflict-resolver modal PR', plan: 'Q1 Launch', priority: 5, due: 'today', progress: 0, labels: [1], assignees: ['u3'] },
    { title: 'Write 1:1 notes for Diego', plan: 'Personal', priority: 3, due: null, progress: 0, personal: true, labels: [], assignees: [] },
    { title: 'Approve Priya\'s time-off request', plan: 'Personal', priority: 3, due: null, progress: 0, personal: true, labels: [], assignees: [] },
    { title: 'Decide telemetry retention window', plan: 'Q1 Launch', priority: 1, due: null, progress: 0, labels: [], assignees: [], carryOver: true },
  ],

  PLANS: [
    { id: 'p1', name: 'Q1 Launch · Web Planner', members: 12, role: 'owner', updated: 'just now' },
    { id: 'p2', name: 'Rituals · weekly ops', members: 6, role: 'editor', updated: '2h ago' },
    { id: 'p3', name: 'Hiring · Q2 engineering', members: 4, role: 'viewer', updated: '5h ago' },
    { id: 'p4', name: 'Design system v3', members: 8, role: 'editor', updated: '1d ago' },
    { id: 'p5', name: 'Personal · errands', members: 1, role: 'owner', updated: '3d ago', personal: true },
    { id: 'p6', name: 'Personal · reading list', members: 1, role: 'owner', updated: '1w ago', personal: true },
  ],

  SCHEDULE_DAYS: ['Mon 20', 'Tue 21', 'Wed 22', 'Thu 23', 'Fri 24', 'Sat 25', 'Sun 26'],
}

Object.assign(window, { PLANNER_DATA })
